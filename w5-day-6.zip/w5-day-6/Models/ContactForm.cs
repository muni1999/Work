﻿using System.ComponentModel.DataAnnotations;

namespace Week5_Test.Models
{
    public class ContactForm
    {
        [Required(ErrorMessage = "Name is required")]
        [StringLength(50)]
        public string Name { get; set; }

        [Required(ErrorMessage = "Email is required")]
        [EmailAddress(ErrorMessage = "Invalid Email")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Message is required")]
        [StringLength(200)]
        public string Message { get; set; }
    }
}
