using Microsoft.AspNetCore.Mvc;
using Week5_Test.Models;

namespace Week5_Test.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult About()
        {
            return View();
        }

        [HttpGet]
        public IActionResult Contact()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Contact(ContactForm form)
        {
            if (!ModelState.IsValid)
            {
                return View(form);
            }

            // Pass data to success page
            ViewBag.Name = form.Name;
            ViewBag.Email = form.Email;
            ViewBag.Message = form.Message;

            return View("Success");
        }
    }
}

